# alt:V Voice Gamemode

Voice Gamemode for alt:V by [DasChaos](https://github.com/ThomasMarangoni)

## Features

- You can talk with players near you

## Commands

| Chat Command | Description               |
| ------------ | ------------------------- |
| /voice       | Opens help page for voice |

## Dependencies

- Chat Resource | [GitHub](https://github.com/altmp/chat)
- JS-Module
